import"./DoCuKfp-.js";const s=globalThis.setInterval;export{s};
