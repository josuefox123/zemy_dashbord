import{X as s}from"./DoCuKfp-.js";const m=s("/images/logozemy.png");export{m as _};
